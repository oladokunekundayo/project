function myFunction() {
		window.print();
					}
function clicked() {
		alert('THANK YOU FOR SUBSCRIBING');
	}
					
function countdown(){
			today = new Date();
			BigDay = new Date("December 20, 2016");
			msPerDay = 24 * 60 * 60 * 1000 ;
			timeLeft = (BigDay.getTime() - today.getTime());
			e_daysLeft = timeLeft / msPerDay;
			daysLeft = Math.floor(e_daysLeft);
			document.write("There are only " + daysLeft + " days left until the end of the semester!");
			
			return this;
}

/*
function openPage(event, pageName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("page");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(pageName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}*/